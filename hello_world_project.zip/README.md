# Hello World Project

This is a simple Python project that prints "Hello World".

## Files
- `hello_world.py`: Main script that prints Hello World.

## How to Run
```bash
python hello_world.py
```
